package com.ts.codemetrics.service.provider.pmprovider.Jira;

import com.atlassian.jira.rest.client.api.domain.Issue;
import com.ts.codemetrics.model.v1.PMToolConfigModel;
import com.ts.codemetrics.model.v1.ProjectReleaseItemModel;
import com.ts.codemetrics.service.provider.pmprovider.Jira.mapper.IssueLinkToReleaseItemMapper;
import com.ts.codemetrics.service.provider.pmprovider.Jira.mapper.JiraResponseToModelMapper;
import com.ts.codemetrics.service.provider.pmprovider.PMToolProvider;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.StreamSupport;

@Service
public class JiraProvider implements PMToolProvider {
    @Override
    public Optional<ProjectReleaseItemModel> getIssue(PMToolConfigModel pmToolConfigModel, String issueKey) {
        ProjectReleaseItemModel releaseItemModel = new ProjectReleaseItemModel();
        JiraClient jiraClient = new JiraClient(pmToolConfigModel.getLoginId(),
                pmToolConfigModel.getPassword(), pmToolConfigModel.getUrl());
        Optional<Issue> issue = jiraClient.getIssue(issueKey);
        if (issue.isPresent()) {
            releaseItemModel = JiraResponseToModelMapper.convertIssueResponseToModel(issue.get());
            ProjectReleaseItemModel finalReleaseItemModel = releaseItemModel;
            if(Objects.nonNull(issue.get().getIssueLinks()) && StreamSupport.stream(issue.get().getIssueLinks().spliterator(), false).count() > 0){
                Optional<List<ProjectReleaseItemModel>>releaseItemModels = IssueLinkToReleaseItemMapper.map(issue.get().getIssueLinks());
                releaseItemModels.ifPresent(res-> {
                    finalReleaseItemModel.setChildItems(res);
                });
            }
            return Optional.of(finalReleaseItemModel);
        }
        return Optional.empty();
    }

    @Override
    public Optional<List<ProjectReleaseItemModel>> getIssues(PMToolConfigModel pmToolConfigModel, List<String> workItemCodes) {
        JiraClient jiraClient = new JiraClient(pmToolConfigModel.getLoginId(),
                pmToolConfigModel.getPassword(), pmToolConfigModel.getUrl());
        Optional<List<Issue>> issues = jiraClient.findIssues(workItemCodes);
        if (issues.isPresent()) {
            return JiraResponseToModelMapper.convertIssuesResponseToModels(issues);
        }
        return Optional.empty();
    }

    @Override
    public String providerName() {
        return "JIRA";
    }
}
