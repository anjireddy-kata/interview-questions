package com.ts.codemetrics.service.provider.pmprovider.Jira;

import com.atlassian.jira.rest.client.api.JiraRestClient;
import com.atlassian.jira.rest.client.api.domain.Issue;
import com.atlassian.jira.rest.client.api.domain.IssueField;
import com.atlassian.jira.rest.client.api.domain.IssueType;
import com.atlassian.jira.rest.client.api.domain.SearchResult;
import com.atlassian.jira.rest.client.internal.async.AsynchronousJiraRestClientFactory;
import org.apache.commons.collections.CollectionUtils;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

//@Component
public class JiraClient {
    private String username;
    private String password;
    private String jiraUrl;
    private JiraRestClient restClient;

    public JiraClient(String username, String password, String jiraUrl) {
        this.username = username;
        this.password = password;
        this.jiraUrl = jiraUrl;
        this.restClient = getJiraRestClient();
    }

    public Optional<Issue> getIssue(String issueKey) {
        try {
            SearchResult issues = findIssue(issueKey);
            if (issues.getTotal() > 0) {
                Issue issue = restClient.getIssueClient().getIssue(issueKey).claim();
                return Optional.of(issue);
            } else {
                return Optional.empty();
            }
        } catch (Exception ex) {
            System.out.println(ex.toString());
        }
        return Optional.empty();
    }

    private SearchResult findIssue(String id) {
        return restClient.getSearchClient().searchJql("issue = " + id).claim();
    }

    public Optional<List<Issue>> findIssues(List<String> workItemCodes) {
        SearchResult searchResult = restClient.getSearchClient().searchJql("issue IN ( " + String.join(",", workItemCodes) + ")").claim();
        List<Issue> result = new ArrayList<>();

        if (Objects.nonNull(searchResult)) {
            for (Issue issue : searchResult.getIssues()) {
                result.add(issue);
                // IssueField issueField = issue.getFieldByName("Sprint");
            }
        }
        return CollectionUtils.isNotEmpty(result) ? Optional.of(result) : Optional.empty();
    }

    private JiraRestClient getJiraRestClient() {
        return new AsynchronousJiraRestClientFactory()
                .createWithBasicHttpAuthentication(getJiraUri(), this.username, this.password);
    }

    private URI getJiraUri() {
        return URI.create(this.jiraUrl);
    }
}
