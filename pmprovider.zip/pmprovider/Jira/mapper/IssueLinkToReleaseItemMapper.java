package com.ts.codemetrics.service.provider.pmprovider.Jira.mapper;

import com.atlassian.jira.rest.client.api.domain.Issue;
import com.atlassian.jira.rest.client.api.domain.IssueLink;
import com.atlassian.jira.rest.client.api.domain.IssueLinkType;
import com.ts.codemetrics.model.v1.ProjectReleaseItemModel;
import com.ts.codemetrics.utils.Enums;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.StreamSupport;

public class IssueLinkToReleaseItemMapper {
    public static Optional<List<ProjectReleaseItemModel>> map(Iterable<IssueLink> issueLinks) {
        List<ProjectReleaseItemModel> releaseItemModels = new ArrayList<>();
        if (Objects.nonNull(issueLinks) && StreamSupport.stream(issueLinks.spliterator(), false).count() > 0) {
            issueLinks.forEach(link -> {
                ProjectReleaseItemModel projectReleaseItemModel = new ProjectReleaseItemModel();
                projectReleaseItemModel.setItemCode(link.getTargetIssueKey());
                projectReleaseItemModel.setChildItem(Boolean.TRUE);
                projectReleaseItemModel.setChildItemDirection(IssueLinkType.Direction.INBOUND.equals(link.getIssueLinkType().getDirection())
                        ? Enums.Direction.INBOUND : Enums.Direction.OUTBOUND);
                releaseItemModels.add(projectReleaseItemModel);
            });
            return Optional.of(releaseItemModels);
        }
        return Optional.empty();
    }
}
