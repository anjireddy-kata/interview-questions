package com.ts.codemetrics.service.provider.pmprovider.Jira.mapper;

import com.atlassian.jira.rest.client.api.domain.*;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ts.codemetrics.model.v1.ProjectReleaseItemModel;
import com.ts.codemetrics.model.v1.VersionModel;
import com.ts.codemetrics.utils.Enums;
import org.apache.commons.collections.CollectionUtils;
import org.codehaus.plexus.util.StringUtils;
import org.joda.time.DateTime;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.StreamSupport;

public class JiraResponseToModelMapper {
    public static ProjectReleaseItemModel convertIssueResponseToModel(Issue issue) {
        ProjectReleaseItemModel releaseItemModel = new ProjectReleaseItemModel();
        if (Objects.nonNull(issue)) {
            releaseItemModel.setTitle(issue.getSummary());
            releaseItemModel.setDescription(issue.getDescription());
            Iterable<Version> versions = issue.getFixVersions();
            List<VersionModel> versionModels = new ArrayList<>();
            if (Objects.nonNull(versions) && StreamSupport.stream(versions.spliterator(), false).count() > 0) {
                versions.forEach(x ->
                        convertVersionEntityToModel(x)
                                .ifPresent(res -> versionModels.add(res)));
                releaseItemModel.setFixedVersion(versionModels.stream().findFirst().get().getReleaseNumber());
            }
            Iterable<Version> affectedVersions = issue.getAffectedVersions();
            if (Objects.nonNull(affectedVersions)&& StreamSupport.stream(affectedVersions.spliterator(), false).count() > 0) {
                affectedVersions.forEach(x ->
                        convertVersionEntityToModel(x)
                                .ifPresent(res -> versionModels.add(res)));
                releaseItemModel.setAffectedVersion(versionModels.stream().findFirst().get().getReleaseNumber());
            }
            if (CollectionUtils.isNotEmpty(versionModels)) {
                releaseItemModel.setVersions(versionModels);
                releaseItemModel.setReleaseNumber(versionModels.stream().findFirst().get().getReleaseNumber());
            }
            Iterable<IssueLink> issueLinks = issue.getIssueLinks();
            if (Objects.nonNull(issueLinks)) {
                List<String> childItems = new ArrayList<>();
                releaseItemModel.setIssuesCount(StreamSupport.stream(issueLinks.spliterator(), false).count());
                issueLinks.forEach(issueLink -> childItems.add(issueLink.getTargetIssueKey()));
                Optional<List<ProjectReleaseItemModel>> releaseItemModels = IssueLinkToReleaseItemMapper.map(issueLinks);
                if(releaseItemModels.isPresent()){
                    releaseItemModel.setChildItems(releaseItemModels.get());
                }
            }
            releaseItemModel.setItemCode(issue.getKey());
            Status status = issue.getStatus();
            releaseItemModel.setStatus(status.getName());
            IssueType issueType = issue.getIssueType();
            User assignee = issue.getAssignee();
            if (Objects.nonNull(assignee)) {
                releaseItemModel.setAssignedTo(StringUtils.isNotBlank(assignee.getDisplayName()) ?
                        assignee.getDisplayName() : assignee.getEmailAddress());
            }
            User reportedBy = issue.getReporter();
            if (Objects.nonNull(reportedBy)) {
                releaseItemModel.setReportedBy(StringUtils.isNotBlank(reportedBy.getDisplayName())
                        ? reportedBy.getDisplayName() : reportedBy.getEmailAddress());
            }
            if (Objects.nonNull(issueType)) {
                if (issueType.getName().equalsIgnoreCase("EPIC")) {
                    releaseItemModel.setWorkItemType(Enums.WorkItemType.Epic);
                } else if (issueType.getName().equalsIgnoreCase("SUBTASK")) {
                    releaseItemModel.setWorkItemType(Enums.WorkItemType.SubTask);
                } else if (issueType.getName().equalsIgnoreCase("STORY")) {
                    releaseItemModel.setWorkItemType(Enums.WorkItemType.Story);
                } else if (issueType.getName().equalsIgnoreCase("BUG")) {
                    releaseItemModel.setWorkItemType(Enums.WorkItemType.Bug);
                }
            }
            ObjectMapper objectMapper = new ObjectMapper();
            try {
                objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
                releaseItemModel.setJsonResponse(objectMapper.writeValueAsString(issue));
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        return releaseItemModel;
    }

    private static Optional<List<ProjectReleaseItemModel>> map(Iterable<IssueLink> issueLinks){
        if(Objects.nonNull(issueLinks) && StreamSupport.stream(issueLinks.spliterator(), false).count() > 0){
            return IssueLinkToReleaseItemMapper.map(issueLinks);
        }
        return Optional.empty();
    }

    private static Optional<VersionModel> convertVersionEntityToModel(Version version) {
        if (Objects.nonNull(version)) {
            VersionModel versionModel = new VersionModel();
            versionModel.setEndDate(version.getReleaseDate().toDate());
            versionModel.setStartDate(null);
            versionModel.setDescription(version.getDescription());
            versionModel.setReleaseNumber(version.getName());
            return Optional.ofNullable(versionModel);
        }
        return Optional.empty();
    }

    public static Optional<List<ProjectReleaseItemModel>> convertIssuesResponseToModels(Optional<List<Issue>> issues) {
        List<ProjectReleaseItemModel> releaseItems = new ArrayList<>();
        if (issues.isPresent()) {
            issues.get().stream().forEach(issue ->
                    releaseItems.add(convertIssueResponseToModel(issue))
            );
            return Optional.of(releaseItems);
        }
        return Optional.empty();
    }


}
