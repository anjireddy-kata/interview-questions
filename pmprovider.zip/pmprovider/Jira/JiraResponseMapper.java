package com.ts.codemetrics.service.provider.pmprovider.Jira;

public class JiraResponseMapper {

}
