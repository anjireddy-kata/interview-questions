package com.ts.codemetrics.service.provider.pmprovider;

import com.ts.codemetrics.model.v1.PMToolConfigModel;
import com.ts.codemetrics.model.v1.ProjectReleaseItemModel;

import java.util.List;
import java.util.Optional;

public interface PMToolProvider {
    Optional<ProjectReleaseItemModel> getIssue(PMToolConfigModel pmToolConfigModel, String issueKey);
    Optional<List<ProjectReleaseItemModel>> getIssues(PMToolConfigModel pmToolConfigModel, List<String> workItemCodes);
    String providerName();
}
